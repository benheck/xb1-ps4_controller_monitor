This example shows the basic usage or the library. 
